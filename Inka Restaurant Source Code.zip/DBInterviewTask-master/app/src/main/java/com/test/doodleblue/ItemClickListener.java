package com.test.doodleblue;

public interface ItemClickListener {
    public void OnItemClick(int id,int val);
}
